module Main (main) where

import IDE.Web.Main (develMain)

main :: IO ()
main = develMain

